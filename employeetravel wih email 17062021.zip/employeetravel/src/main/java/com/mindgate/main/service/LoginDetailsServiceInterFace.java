package com.mindgate.main.service;

import java.util.List;

import com.mindgate.main.pojo.LoginDetails;

public interface LoginDetailsServiceInterFace {
	public LoginDetails getLoginDetailsByLoginId(int loginId);

	public List<LoginDetails> getAllLoginDetails();

	public LoginDetails login(LoginDetails loginDetails);

}
